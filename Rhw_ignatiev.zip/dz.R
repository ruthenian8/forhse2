---
  title: "HW. Advanced tidyverse "
output: html_document
---
  
  
  
  ## Corpus of bilingual children's speech 
  Data: https://www.kaggle.com/rtatman/corpus-of-bilingual-childrens-speech?select=guide_to_files.csv

The Paradis corpus consists of naturalistic language samples from 25 children learning English as a second language (English language learners or learners of English as an additional language). Participants in this study were children from newcomer (immigrant and refugee) families to Canada. The children started to learn English as a second language (L2) after their first language (L1) had been established.

Variables:
  
  - age_of_arrival_to_Canada_months 

- age_of_English_exposure_months(the age of onset of English acquisition) 

- age_at_recording_months

- months_of_english


## Import required libraries
library(tidyverse)
library(data.table)

## 1. Data 

### 1.1 Read guide_to_files.csv and create 'biling_speech_data' dataframe

guide <- read.csv("./guide_to_files.csv")

guide <- tibble(guide)

### 1.2 Use `'biling_speech_data'` dataframe and functions from tidyverse to answer the following questions:


 
#1. How many participants are mentioned in this dataframe?
guide %>% 
  summarise(n = n())

#n
#<int>
#1    24

#2. How many of them are males and females?

guide %>%
  group_by(gender) %>%
  summarise(n = n())
#gender     n
#<chr>  <int>
#1 F          8
#2 M         16

#3. How many first languages are mentioned in the dataframe?
guide %>%
  group_by(first_language) %>%
  summarise(n = n()) %>% 
  summarise(num = n())
#num
#<int>
#1     9

## 2. Changing Data

### 2.1 Choose all numeric columns from the dataframe using tidyselect. Check if there are NA in columns.  

guide %>% 
  select(where(is_numeric)) %>% 
  select(where(function(x) !any(is.na(x))))

### 2.2 Convert all numerical data in the columns chosen before from months to years. Don't forget to save results in the dataframe! 

guide <- guide %>% 
  mutate(age_of_arrival_to_Canada_months = age_of_arrival_to_Canada_months / 12) %>% 
  mutate(age_of_English_exposure_months = age_of_English_exposure_months / 12) %>% 
  mutate(age_at_recording_months = age_at_recording_months / 12) %>% 
  mutate(months_of_english = months_of_english / 12)

### 2.3 Rename changed columns for convenience

guide <- rename(guide, 
                arrival_age = age_of_arrival_to_Canada_months, 
                exposure_age = age_of_English_exposure_months,
                recording_age = age_at_recording_months,
                learning_age = months_of_english
                )

## 3. Analysis of Data

### 3.1 Answer the questions below using advanced functions of tidyverse

#1. What is the average age of child migration to Canada? 

guide %>% 
  summarise(mean_arrival = mean(arrival_age))
#mean_arrival
#<dbl>
#1         3.74

#2. How many children whose first language is Spanish learnt English less than 10 month? How many of them are males and females?

guide %>% 
  filter(first_language == "Spanish") %>% 
  filter(learning_age * 12 < 10) %>% 
  group_by(gender) %>% 
  summarise(num = n())

#gender   num
#<chr>  <int>
#1 M        3

#3. What is the average age of children speaking the same first language at recording? What is the average migration age of children speaking the same first language?

guide %>% 
  group_by(first_language) %>% 
  summarise(avg_rec_age = mean(recording_age), avg_mig_age = mean(arrival_age))

#first_language avg_rec_age avg_mig_age
#<chr>                <dbl>       <dbl>
#1 Arabic                4.64      0.0833
#2 Cantonese             4.92      0.0833
#3 Farsi                 5.58      4.42  
#4 Japanese              4.25      2.17  
#5 Korean                5.17      4     
#6 Mandarin              5.65      4.79  
#7 Romanian              6.17      5.75  
#8 Spanish               5.97      4.97  
#9 Ukrainian             6.58      5.5   

### 3.2 Find out mean, min and max age of onset of English acquisition for female and male participants with the help of advanced functions of tidyverse. Add information about their first language. 

guide %>% 
  group_by(gender) %>% 
  summarise(min_start = min(learning_age), 
            mean_start = mean(learning_age), 
            max_start = max(learning_age))

#gender min_start mean_start max_start
#<chr>      <dbl>      <dbl>     <dbl>
#1 F          0.167      0.698      1.5 
#2 M          0.417      0.833      1.33

### 3.3 Sort the data alphabetically by the column 'first_language'.

guide %>% 
  arrange(first_language)

##When do children learn words?

Data: https://www.kaggle.com/rtatman/when-do-children-learn-words?select=main_data.csv

The main dataset includes information for 732 Norwegian words. A second table also includes measures of how frequently each word is used in Norwegian, both on the internet (as observed in the Norwegian Web as Corpus dataset) and when an adult is talking to a child.

Main data necessary (!) variables:

Translation: the English translation of the Norwegian word

AoA: how old a child generally was when they learnt this word, in months

VSoA: how many other words a child generally knows when they learn this word (rounded up to the nearest 10)

Broad_lex: the broad part of speech of the word

CDS_Freq: a measure of how commonly this word occurs when a Norwegian adult is talking to a Norwegian child

Norwegian CDS Frequency necessary (!) variables:

Translation: The English translation of the Norwegian word

Freq_NoWaC: How often this word is used on the internet

Freq_CDS: How often this word is used when talking to children (based on two Norwegian CHILDES corpora)

NB! All the other columns should be deleted for your convenience. 

NB!'Freq_CDS' and 'CDS_Freq' columns are the same. 

## 4. Data 

### 4.1 Read two tables 

main <- read.csv("./main_data.csv")
main <- tibble(main)
cds_freq <- read.csv("./Norwegian_CDS_frequency.csv")
cds_freq <- tibble(cds_freq)

### 4.2 Leave only necessary columns

main <- main %>% 
  select(Translation, AoA, VSoA, Broad_lex, CDS_freq)

cds_freq <- cds_freq %>% 
  select(Translation, Freq_NoWaC, Freq_CDS)

### 4.3  Join two tables and create a new dataframe 'norw_words'. NB! There shouldn't be duplicates in your new dataframe. 

norw_words <- main %>% 
  full_join(cds_freq)

### 4.4   Leave only 15 first rows
 
norw_words <- norw_words %>% 
  slice_head(n = 15)


## 5. Experiments

### 5.1  Create a tibble 'freq_statistics' using 3 columns: 'Translation', 'CDS_Freq', 'Freq_NoWaC'

freq_statistics <- norw_words %>% 
  select(Translation, CDS_freq, Freq_NoWaC)


#Change the format of the tibble using the function tidyr::pivot_longer() or tidyr::pivot_wider().

freq_statistics %>% 
  pivot_longer(cols = CDS_freq:Freq_NoWaC, names_to = "Corpus", values_to = "Frequency")

### 5.2  Get a string vector output with information about classes in the tibble. 

freq_statistics %>% 
  dplyr::summarise_all(class) %>% 
  tidyr::gather(variable, class) %>% 
  pull(class, variable)
# "character" "character" "character"

# Present the same information as a dataframe. 

freq_statistics %>% 
   dplyr::summarise_all(class) %>% 
   tidyr::gather(variable, class)

### 5.3  Convert values from 'CDS_Freq' & 'Freq_NoWaC' to numeric ones. 

freq_statistics <- suppressWarnings(freq_statistics %>% 
  mutate(CDS_freq = as.numeric(CDS_freq),
         Freq_NoWaC = as.numeric(Freq_NoWaC)))

Get average values of all numeric classes in 'norw_words'.

suppressWarnings(norw_words %>% 
  select(AoA, VSoA, CDS_freq, Freq_NoWaC, Freq_CDS) %>% 
  mutate(AoA = as.numeric(AoA),
                          VSoA = as.numeric(VSoA),
                          CDS_freq = as.numeric(CDS_freq),
                          Freq_NoWaC = as.numeric(Freq_NoWaC),
                          Freq_CDS = as.numeric(Freq_CDS)) %>% 
  summarise(mean_AOA = mean(AoA, na.rm = TRUE),
            mean_VSoA = mean(VSoA, na.rm = TRUE),
            mean_CDSf = mean(CDS_freq, na.rm = TRUE),
            mean_nowac = mean(Freq_NoWaC, na.rm = TRUE),
            mean_FC = mean(Freq_CDS, na.rm = TRUE)))

#mean_AOA mean_VSoA mean_CDSf mean_nowac mean_FC
# <dbl>     <dbl>     <dbl>      <dbl>   <dbl>
#1     18.8      131.      40.6      28156    40.6

### 5.4   Create a nested table (by 'Translation')
 
freq_statistics %>% 
  nest(data = c(CDS_freq, Freq_NoWaC))

#Translation         data                
#<chr>               <list>              
#1 'ouch'              <tibble[,2] [1 × 2]>
#2 'baa baa'           <tibble[,2] [1 × 2]>
# ...
